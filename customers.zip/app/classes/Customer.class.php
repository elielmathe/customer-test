<?php
	class Customer extends User{
		
	}
