<?php
	class Agent extends User{
		
		
	}
